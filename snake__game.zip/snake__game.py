import turtle
import random
import time

delay = 0.1
sc = 0
hs = 0

# Snake body list
bodies = []

# Screen setup
s1 = turtle.Screen()
s1.title("Snake Game")
s1.bgcolor("light blue")
s1.setup(width=600, height=600)

# Snake head
head = turtle.Turtle()
head.speed(0)
head.shape("circle")
head.color("red")
head.fillcolor("black")
head.penup()
head.goto(0, 0)
head.direction = "stop"

# Food
food = turtle.Turtle()
food.speed(0)
food.shape("square")
food.color("grey")
food.penup()
food.goto(250, 200)

# Scoreboard
score = turtle.Turtle()
score.speed(0)
score.color("black")
score.penup()
score.hideturtle()
score.goto(-250, 250)
score.write("Score: 0  |  Highest Score: 0", font=("Arial", 14, "normal"))

# Movement functions
def moveUp():
    if head.direction != "down":
        head.direction = "up"

def moveDown():
    if head.direction != "up":
        head.direction = "down"

def moveLeft():
    if head.direction != "right":
        head.direction = "left"

def moveRight():
    if head.direction != "left":
        head.direction = "right"

def moveStop():
    head.direction = "stop"

# Movement logic
def move():
    if head.direction == "up":
        head.sety(head.ycor() + 20)
    if head.direction == "down":
        head.sety(head.ycor() - 20)
    if head.direction == "left":
        head.setx(head.xcor() - 20)
    if head.direction == "right":
        head.setx(head.xcor() + 20)

# Keyboard bindings
s1.listen()
s1.onkey(moveUp, "Up")
s1.onkey(moveDown, "Down")
s1.onkey(moveLeft, "Left")
s1.onkey(moveRight, "Right")
s1.onkey(moveStop, "space")

# Main game loop with error handling
try:
    while True:
        s1.update()

        # Border collision wrap
        if head.xcor() > 290:
            head.setx(-290)
        if head.xcor() < -290:
            head.setx(290)
        if head.ycor() > 290:
            head.sety(-290)
        if head.ycor() < -290:
            head.sety(290)

        # Collision with food
        if head.distance(food) < 20:
            x = random.randint(-280, 280)
            y = random.randint(-280, 280)
            food.goto(x, y)

            # Add new body part
            body = turtle.Turtle()
            body.speed(0)
            body.penup()
            body.shape("square")
            body.color("green")
            bodies.append(body)

            # Update score
            sc += 100
            if sc > hs:
                hs = sc
            score.clear()
            score.write(f"Score: {sc}  |  Highest Score: {hs}", font=("Arial", 14, "normal"))

            delay = max(0.05, delay - 0.001)

        # Move body segments
        for i in range(len(bodies)-1, 0, -1):
            x = bodies[i - 1].xcor()
            y = bodies[i - 1].ycor()
            bodies[i].goto(x, y)

        if len(bodies) > 0:
            bodies[0].goto(head.xcor(), head.ycor())

        move()

        # Collision with own body
        for b in bodies:
            if b.distance(head) < 20:
                time.sleep(1)
                head.goto(0, 0)
                head.direction = "stop"

                for b in bodies:
                    b.hideturtle()
                bodies.clear()

                sc = 0
                delay = 0.1
                score.clear()
                score.write(f"Score: {sc}  |  Highest Score: {hs}", font=("Arial", 14, "normal"))

        time.sleep(delay)

except turtle.Terminator:
    print("Turtle graphics window closed. Exiting safely.")
